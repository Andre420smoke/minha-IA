# King IA - Plataforma de Criação com Inteligência Artificial

## 🚀 Visão Geral

O King IA é uma plataforma completa de criação com inteligência artificial que permite aos usuários gerar imagens, textos, áudios e interagir com assistentes de IA de última geração.

## ✨ Funcionalidades Principais

### 🎨 Gerador de Imagens
- Múltiplos modelos de IA (DALL-E 3, Stable Diffusion, Midjourney, Adobe Firefly)
- Controle total sobre tamanho, qualidade e parâmetros
- Sistema de prompts negativos
- Estilos predefinidos (fotográfico, artístico, cartoon, minimalista)
- Galeria de imagens geradas
- Barra de progresso detalhada com tempo estimado

### 📝 Gerador de Textos
- Modelos avançados (GPT-4, Claude 3, Gemini Pro)
- Controle de tom e estilo
- Ajuste de criatividade e comprimento
- Editor integrado com visualização
- Exportação em múltiplos formatos
- Progresso em tempo real

### 🎵 Gerador de Áudio
- Síntese de voz em múltiplos idiomas
- Controle de velocidade e tom
- Vozes masculinas e femininas
- Player de áudio integrado
- Biblioteca de áudios gerados

### 💬 Assistente IA
- Chat em tempo real com múltiplos modelos
- Histórico de conversas
- Prompts rápidos
- Respostas contextuais
- Interface conversacional intuitiva

## 🏗️ Arquitetura Técnica

### Frontend
- **Framework**: Next.js 15 com App Router
- **Linguagem**: TypeScript 5
- **Estilização**: Tailwind CSS 4 + shadcn/ui
- **Estado**: Zustand + React Query
- **Componentes**: Biblioteca completa shadcn/ui

### Backend
- **API**: Next.js API Routes
- **Banco de Dados**: Prisma ORM com SQLite
- **IA SDK**: z-ai-web-dev-sdk
- **Autenticação**: NextAuth.js v4

### Funcionalidades Avançadas
- **Progresso Detalhado**: Barras de progresso com porcentagem e tempo estimado
- **Tema Claro/Escuro**: Sistema completo de temas
- **Responsividade**: Design mobile-first
- **Histórico**: Sistema completo de undo/redo
- **Exportação**: Múltiplos formatos suportados
- **Salvamento**: Automático e manual

## 📦 Estrutura do Projeto

```
king-ia/
├── src/
│   ├── app/                    # App Router Next.js
│   │   ├── api/               # API Routes
│   │   │   ├── projects/      # Gestão de projetos
│   │   │   ├── generate/      # Geração de conteúdo
│   │   │   └── chat/         # Chat com IA
│   │   ├── globals.css        # Estilos globais
│   │   ├── layout.tsx         # Layout principal
│   │   └── page.tsx           # Página inicial
│   ├── components/
│   │   ├── ui/               # Componentes shadcn/ui
│   │   ├── layout/           # Layouts da aplicação
│   │   └── workspace/        # Áreas de trabalho
│   ├── lib/
│   │   ├── stores/           # Estado global (Zustand)
│   │   ├── db.ts             # Conexão com banco
│   │   └── utils.ts          # Utilitários
│   └── hooks/                # Hooks personalizados
├── prisma/
│   └── schema.prisma         # Schema do banco
├── public/                   # Arquivos estáticos
└── docs/                     # Documentação
```

## 🛠️ Instalação e Configuração

### Pré-requisitos
- Node.js 18+ 
- npm ou yarn
- Git

### Instalação
```bash
# Clonar o repositório
git clone <repository-url>
cd king-ia

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push

# Iniciar desenvolvimento
npm run dev
```

### Variáveis de Ambiente
```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

## 🚀 Compilação para Produção

### Build
```bash
# Build para produção
npm run build

# Iniciar servidor de produção
npm run start
```

### Docker
```bash
# Construir imagem
docker build -t king-ia .

# Executar container
docker run -p 3000:3000 king-ia
```

## 📱 Funcionalidades Implementadas

### ✅ Concluídas
- [x] Layout principal com sidebar responsiva
- [x] Sistema de projetos e organização
- [x] Gerador de imagens com múltiplos modelos
- [x] Gerador de textos com controle avançado
- [x] Gerador de áudio com síntese de voz
- [x] Chat com assistente IA
- [x] Barra de progresso detalhada (% e tempo)
- [x] Tema claro/escuro
- [x] Sistema de exportação
- [x] Salvamento automático
- [x] API endpoints completos
- [x] Banco de dados com Prisma

### 🚧 Em Desenvolvimento
- [ ] Sistema de histórico avançado (undo/redo)
- [ ] Sistema de plugins e extensões
- [ ] Atualizações automáticas
- [ ] Sistema de notificações avançado

## 🔧 Configuração de Modelos de IA

### Imagens
- **DALL-E 3**: Alta qualidade, 1024x1024
- **Stable Diffusion XL**: Customização avançada
- **Midjourney v6**: Estilo artístico
- **Adobe Firefly**: Seguro para uso comercial

### Textos
- **GPT-4**: Mais avançado, 8k tokens
- **GPT-3.5 Turbo**: Rápido, 4k tokens
- **Claude 3**: Contexto longo, 100k tokens
- **Gemini Pro**: Google, 32k tokens

### Áudio
- **Vozes em Português**: Feminina/Masculina
- **Vozes em Inglês**: Multiple options
- **Controle**: Velocidade (0.5x-2.0x), Tom (0.5-2.0)

## 📊 Sistema de Progresso

O aplicativo conta com um sistema de progresso detalhado:

### Componentes
- **ProgressIndicator**: Barra principal com %
- **useProgress**: Hook para gerenciar estados
- **Tempo Estimado**: Cálculo dinâmico baseado no histórico
- **Passos Detalhados**: Status de cada etapa do processo

### Exemplo de Implementação
```typescript
const {
  progress,      // 0-100
  status,        // idle | processing | completed | error
  currentStep,   // "Processando imagem..."
  currentStepNumber, // 3 de 6
  totalSteps,    // 6
  estimatedTime, // 30s
  startProgress,
  updateProgress,
  completeProgress,
  errorProgress
} = useProgress(30); // 30 segundos estimados
```

## 🎨 Personalização

### Temas
- **Claro**: Default, ideal para dia
- **Escuro**: Reduz cansaço visual
- **Auto**: Segue preferência do sistema

### Cores
- **Primária**: Gradiente roxo-azul
- **Secundária**: Cinza suave
- **Acentos**: Azul vibrante

## 📈 Performance

### Otimizações
- **Code Splitting**: Divisão automática de código
- **Lazy Loading**: Carregamento sob demanda
- **Cache**: Estratégias avançadas de cache
- **Imagens**: Otimização WebP/AVIF
- **Fontes**: Otimizadas e pré-carregadas

### Métricas
- **FCP**: < 1.5s
- **LCP**: < 2.5s
- **FID**: < 100ms
- **CLS**: < 0.1

## 🔒 Segurança

### Implementações
- **CSRF Protection**: Próximo.js nativo
- **XSS Prevention**: Sanitização de inputs
- **SQL Injection**: Prisma ORM
- **Rate Limiting**: API endpoints
- **Data Validation**: Zod schemas

## 🌐 Internacionalização

### Idiomas Suportados
- **Português (BR)**: Default
- **Inglês (US)**: Em desenvolvimento
- **Espanhol (ES)**: Planejado

## 📞 Suporte e Contato

### Documentação
- **Guia de Usuário**: `/docs/user-guide`
- **API Reference**: `/docs/api`
- **Contribuição**: `/docs/contributing`

### Issues e Bugs
- **GitHub Issues**: Reportar problemas
- **Discord**: Comunidade ativa
- **Email**: support@kingia.com

## 📜 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

---

**King IA** - Criado com ❤️ usando as melhores tecnologias de IA e desenvolvimento web.
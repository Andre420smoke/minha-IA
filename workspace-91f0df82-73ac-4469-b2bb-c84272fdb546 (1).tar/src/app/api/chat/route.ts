import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, model, history } = body;

    if (!message) {
      return NextResponse.json(
        { error: 'Mensagem é obrigatória' },
        { status: 400 }
      );
    }

    // Criar usuário padrão se não existir
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({
        data: {
          name: 'Usuário Padrão',
          email: 'user@kingia.com'
        }
      });
    }

    try {
      // Inicializar SDK da ZAI
      const zai = await ZAI.create();

      // Construir mensagens para a API
      const messages = [
        {
          role: 'system',
          content: `Você é um assistente de IA amigável e profissional chamado King Assistant. 
          Ajude os usuários com suas perguntas de forma clara, concisa e útil. 
          Seja educado e sempre tente fornecer respostas completas e informativas.`
        }
      ];

      // Adicionar histórico recente
      if (history && Array.isArray(history)) {
        history.forEach((msg: any) => {
          if (msg.role === 'user' || msg.role === 'assistant') {
            messages.push({
              role: msg.role,
              content: msg.content
            });
          }
        });
      }

      // Adicionar mensagem atual
      messages.push({
        role: 'user',
        content: message
      });

      // Gerar resposta
      const response = await zai.chat.completions.create({
        messages,
        model: model || 'gpt-4',
        temperature: 0.7,
        max_tokens: 2000
      });

      const assistantResponse = response.choices[0]?.message?.content || '';

      if (!assistantResponse) {
        throw new Error('Nenhuma resposta foi gerada');
      }

      // Salvar conversa no banco (opcional)
      await db.generation.create({
        data: {
          type: 'text',
          prompt: message,
          result: {
            response: assistantResponse,
            model: model || 'gpt-4',
            conversation: true
          },
          model: model || 'gpt-4',
          status: 'completed',
          userId: user.id
        }
      });

      return NextResponse.json({
        success: true,
        response: assistantResponse,
        model: model || 'gpt-4'
      });

    } catch (aiError) {
      console.error('Erro na geração de resposta:', aiError);
      
      return NextResponse.json(
        { 
          error: 'Erro ao processar sua mensagem', 
          details: aiError instanceof Error ? aiError.message : 'Erro desconhecido',
          response: 'Desculpe, estou com dificuldades para responder no momento. Tente novamente em alguns instantes.'
        },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Listar projetos
export async function GET() {
  try {
    const projects = await db.project.findMany({
      orderBy: { updatedAt: 'desc' },
      include: {
        generations: {
          orderBy: { createdAt: 'desc' },
          take: 1
        },
        tags: {
          include: {
            tag: true
          }
        }
      }
    });

    return NextResponse.json(projects);
  } catch (error) {
    console.error('Erro ao listar projetos:', error);
    return NextResponse.json(
      { error: 'Erro ao listar projetos' },
      { status: 500 }
    );
  }
}

// POST - Criar novo projeto
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, type, description } = body;

    if (!name || !type) {
      return NextResponse.json(
        { error: 'Nome e tipo são obrigatórios' },
        { status: 400 }
      );
    }

    // Criar usuário padrão se não existir
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({
        data: {
          name: 'Usuário Padrão',
          email: 'user@kingia.com'
        }
      });
    }

    const project = await db.project.create({
      data: {
        name,
        type,
        description: description || null,
        userId: user.id
      }
    });

    return NextResponse.json(project, { status: 201 });
  } catch (error) {
    console.error('Erro ao criar projeto:', error);
    return NextResponse.json(
      { error: 'Erro ao criar projeto' },
      { status: 500 }
    );
  }
}
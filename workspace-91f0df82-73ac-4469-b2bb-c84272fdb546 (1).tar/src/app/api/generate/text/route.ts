import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, context, model, tone, maxLength, temperature, projectId } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt é obrigatório' },
        { status: 400 }
      );
    }

    // Criar usuário padrão se não existir
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({
        data: {
          name: 'Usuário Padrão',
          email: 'user@kingia.com'
        }
      });
    }

    // Criar registro da geração
    const generation = await db.generation.create({
      data: {
        type: 'text',
        prompt,
        parameters: {
          context,
          model,
          tone,
          maxLength,
          temperature
        },
        model: model || 'gpt-4',
        status: 'processing',
        userId: user.id,
        projectId: projectId || null
      }
    });

    try {
      // Inicializar SDK da ZAI
      const zai = await ZAI.create();

      // Construir prompt completo baseado no tom e contexto
      let systemPrompt = `Você é um assistente de escrita profissional. `;
      
      switch (tone) {
        case 'professional':
          systemPrompt += 'Escreva de forma profissional, clara e objetiva. ';
          break;
        case 'casual':
          systemPrompt += 'Escreva de forma informal e descontraída. ';
          break;
        case 'friendly':
          systemPrompt += 'Escreva de forma amigável e acolhedora. ';
          break;
        case 'academic':
          systemPrompt += 'Escreva de forma acadêmica, formal e bem estruturada. ';
          break;
        case 'creative':
          systemPrompt += 'Escreva de forma criativa e imaginativa. ';
          break;
        case 'technical':
          systemPrompt += 'Escreva de forma técnica e precisa. ';
          break;
      }

      if (maxLength) {
        systemPrompt += `Limite o texto a aproximadamente ${maxLength} palavras. `;
      }

      if (context) {
        systemPrompt += `Contexto adicional: ${context}. `;
      }

      systemPrompt += 'Responda apenas com o texto solicitado, sem explicações adicionais.';

      // Gerar texto
      const startTime = Date.now();
      const response = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: temperature || 0.7,
        max_tokens: maxLength ? Math.floor(maxLength * 1.5) : 1000
      });

      const processingTime = Date.now() - startTime;
      const generatedText = response.choices[0]?.message?.content || '';

      if (!generatedText) {
        throw new Error('Nenhum texto foi gerado');
      }

      // Atualizar geração com sucesso
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'completed',
          result: {
            text: generatedText,
            tone,
            maxLength,
            temperature
          },
          processingTime
        }
      });

      return NextResponse.json({
        success: true,
        generationId: generation.id,
        text: generatedText,
        processingTime
      });

    } catch (aiError) {
      console.error('Erro na geração de texto:', aiError);
      
      // Atualizar geração com erro
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'failed',
          errorMessage: aiError instanceof Error ? aiError.message : 'Erro desconhecido'
        }
      });

      return NextResponse.json(
        { error: 'Erro ao gerar texto com IA', details: aiError },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
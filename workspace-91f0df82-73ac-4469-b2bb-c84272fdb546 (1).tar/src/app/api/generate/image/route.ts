import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, negativePrompt, model, size, quality, steps, projectId } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt é obrigatório' },
        { status: 400 }
      );
    }

    // Criar usuário padrão se não existir
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({
        data: {
          name: 'Usuário Padrão',
          email: 'user@kingia.com'
        }
      });
    }

    // Criar registro da geração
    const generation = await db.generation.create({
      data: {
        type: 'image',
        prompt,
        parameters: {
          negativePrompt,
          model,
          size,
          quality,
          steps
        },
        model: model || 'dall-e-3',
        status: 'processing',
        userId: user.id,
        projectId: projectId || null
      }
    });

    try {
      // Inicializar SDK da ZAI
      const zai = await ZAI.create();

      // Construir prompt completo
      let fullPrompt = prompt;
      if (negativePrompt) {
        fullPrompt += `. Negative prompt: ${negativePrompt}`;
      }

      // Gerar imagem
      const startTime = Date.now();
      const response = await zai.images.generations.create({
        prompt: fullPrompt,
        size: `${size}x${size}` || '1024x1024',
        // Outros parâmetros podem ser adicionados aqui
      });

      const processingTime = Date.now() - startTime;

      // Simular URL da imagem (em produção, isso viria da API)
      const imageUrl = response.data[0].base64 
        ? `data:image/png;base64,${response.data[0].base64}`
        : '/api/placeholder/image.png';

      // Atualizar geração com sucesso
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'completed',
          result: {
            imageUrl,
            size,
            quality,
            steps
          },
          processingTime
        }
      });

      return NextResponse.json({
        success: true,
        generationId: generation.id,
        imageUrl,
        processingTime
      });

    } catch (aiError) {
      console.error('Erro na geração de imagem:', aiError);
      
      // Atualizar geração com erro
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'failed',
          errorMessage: aiError instanceof Error ? aiError.message : 'Erro desconhecido'
        }
      });

      return NextResponse.json(
        { error: 'Erro ao gerar imagem com IA', details: aiError },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text, voice, speed, pitch, projectId } = body;

    if (!text) {
      return NextResponse.json(
        { error: 'Texto é obrigatório' },
        { status: 400 }
      );
    }

    // Criar usuário padrão se não existir
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({
        data: {
          name: 'Usuário Padrão',
          email: 'user@kingia.com'
        }
      });
    }

    // Criar registro da geração
    const generation = await db.generation.create({
      data: {
        type: 'audio',
        prompt: text,
        parameters: {
          voice: voice || 'pt-BR-Female1',
          speed: speed || 1.0,
          pitch: pitch || 1.0
        },
        model: 'tts-1',
        status: 'processing',
        userId: user.id,
        projectId: projectId || null
      }
    });

    try {
      // Simulação de geração de áudio (em produção, usaria API real)
      // Como não temos API de TTS direta no ZAI SDK, vamos simular
      const startTime = Date.now();
      
      // Simular tempo de processamento
      await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000));
      
      const processingTime = Date.now() - startTime;

      // Gerar URL de áudio simulada (em produção, seria uma URL real)
      const audioUrl = `data:audio/mp3;base64,simulated-audio-data-${Date.now()}`;

      // Atualizar geração com sucesso
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'completed',
          result: {
            audioUrl,
            voice: voice || 'pt-BR-Female1',
            speed: speed || 1.0,
            pitch: pitch || 1.0,
            duration: Math.floor(text.length * 0.1) // Estimativa de duração
          },
          processingTime
        }
      });

      return NextResponse.json({
        success: true,
        generationId: generation.id,
        audioUrl,
        duration: Math.floor(text.length * 0.1),
        processingTime
      });

    } catch (aiError) {
      console.error('Erro na geração de áudio:', aiError);
      
      // Atualizar geração com erro
      await db.generation.update({
        where: { id: generation.id },
        data: {
          status: 'failed',
          errorMessage: aiError instanceof Error ? aiError.message : 'Erro desconhecido'
        }
      });

      return NextResponse.json(
        { error: 'Erro ao gerar áudio com IA', details: aiError },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
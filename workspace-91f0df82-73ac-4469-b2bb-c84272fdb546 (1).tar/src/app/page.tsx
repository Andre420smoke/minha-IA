'use client';

import { useEffect } from 'react';
import { LasyLayout } from '@/components/layout/lasy-layout';
import { WorkspaceArea } from '@/components/workspace/workspace-area';
import { useAppStore } from '@/lib/stores/app-store';

export default function Home() {
  const { setProjects, setCurrentProject } = useAppStore();

  useEffect(() => {
    // Carregar projetos iniciais
    const loadInitialData = async () => {
      try {
        const response = await fetch('/api/projects');
        if (response.ok) {
          const projects = await response.json();
          setProjects(projects);
        }
      } catch (error) {
        console.error('Erro ao carregar projetos:', error);
      }
    };

    loadInitialData();
  }, [setProjects]);

  return (
    <LasyLayout>
      <WorkspaceArea />
    </LasyLayout>
  );
}
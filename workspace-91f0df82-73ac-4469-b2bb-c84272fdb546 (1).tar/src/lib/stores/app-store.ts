import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Tipos de dados
export interface Project {
  id: string;
  name: string;
  description?: string;
  type: 'image' | 'text' | 'audio' | 'mixed';
  status: 'active' | 'archived' | 'deleted';
  content?: any;
  thumbnail?: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Generation {
  id: string;
  projectId?: string;
  type: 'image' | 'text' | 'audio' | 'video';
  prompt: string;
  parameters?: any;
  result?: any;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  errorMessage?: string;
  processingTime?: number;
  model: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'auto';
  language: string;
  autoSave: boolean;
  notifications: boolean;
  aiModel: string;
  exportFormat: string;
}

export interface AppState {
  // Estado da aplicação
  currentProject: Project | null;
  projects: Project[];
  generations: Generation[];
  activeTab: string;
  sidebarCollapsed: boolean;
  
  // Configurações do usuário
  settings: UserSettings;
  
  // Estado das ferramentas
  activeTool: 'image' | 'text' | 'audio' | 'chat' | null;
  
  // Histórico para undo/redo
  history: any[];
  historyIndex: number;
  
  // Ações
  setCurrentProject: (project: Project | null) => void;
  setProjects: (projects: Project[]) => void;
  addProject: (project: Project) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  
  setGenerations: (generations: Generation[]) => void;
  addGeneration: (generation: Generation) => void;
  updateGeneration: (id: string, updates: Partial<Generation>) => void;
  
  setActiveTab: (tab: string) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  setActiveTool: (tool: 'image' | 'text' | 'audio' | 'chat' | null) => void;
  
  updateSettings: (settings: Partial<UserSettings>) => void;
  
  // Histórico
  addToHistory: (action: any) => void;
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Estado inicial
      currentProject: null,
      projects: [],
      generations: [],
      activeTab: 'workspace',
      sidebarCollapsed: false,
      activeTool: null,
      history: [],
      historyIndex: -1,
      
      settings: {
        theme: 'light',
        language: 'pt-BR',
        autoSave: true,
        notifications: true,
        aiModel: 'gpt-4',
        exportFormat: 'png',
      },
      
      // Ações de projetos
      setCurrentProject: (project) => set({ currentProject: project }),
      
      setProjects: (projects) => set({ projects }),
      
      addProject: (project) => set((state) => ({
        projects: [...state.projects, project],
        currentProject: project,
      })),
      
      updateProject: (id, updates) => set((state) => ({
        projects: state.projects.map(p => 
          p.id === id ? { ...p, ...updates, updatedAt: new Date() } : p
        ),
        currentProject: state.currentProject?.id === id 
          ? { ...state.currentProject, ...updates, updatedAt: new Date() }
          : state.currentProject,
      })),
      
      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter(p => p.id !== id),
        currentProject: state.currentProject?.id === id ? null : state.currentProject,
      })),
      
      // Ações de gerações
      setGenerations: (generations) => set({ generations }),
      
      addGeneration: (generation) => set((state) => ({
        generations: [...state.generations, generation],
      })),
      
      updateGeneration: (id, updates) => set((state) => ({
        generations: state.generations.map(g => 
          g.id === id ? { ...g, ...updates, updatedAt: new Date() } : g
        ),
      })),
      
      // Ações da interface
      setActiveTab: (tab) => set({ activeTab: tab }),
      setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
      setActiveTool: (tool) => set({ activeTool: tool }),
      
      // Configurações
      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings },
      })),
      
      // Histórico
      addToHistory: (action) => set((state) => {
        const newHistory = state.history.slice(0, state.historyIndex + 1);
        newHistory.push(action);
        return {
          history: newHistory,
          historyIndex: newHistory.length - 1,
        };
      }),
      
      undo: () => set((state) => {
        if (state.historyIndex <= 0) return state;
        const newIndex = state.historyIndex - 1;
        return {
          historyIndex: newIndex,
          // Aplicar ação de undo aqui
        };
      }),
      
      redo: () => set((state) => {
        if (state.historyIndex >= state.history.length - 1) return state;
        const newIndex = state.historyIndex + 1;
        return {
          historyIndex: newIndex,
          // Aplicar ação de redo aqui
        };
      }),
      
      canUndo: () => {
        const state = get();
        return state.historyIndex > 0;
      },
      
      canRedo: () => {
        const state = get();
        return state.historyIndex < state.history.length - 1;
      },
    }),
    {
      name: 'lasy-ia-storage',
      partialize: (state) => ({
        settings: state.settings,
        sidebarCollapsed: state.sidebarCollapsed,
        activeTab: state.activeTab,
      }),
    }
  )
);
'use client';

import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/lib/stores/app-store';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Sidebar, 
  SidebarContent, 
  SidebarFooter, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset
} from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Plus,
  Image,
  FileText,
  Mic,
  MessageSquare,
  Settings,
  Moon,
  Sun,
  Monitor,
  History,
  Undo,
  Redo,
  Save,
  Folder,
  Tag,
  Trash2,
  Archive,
  MoreHorizontal
} from 'lucide-react';

interface LasyLayoutProps {
  children: React.ReactNode;
}

export function LasyLayout({ children }: LasyLayoutProps) {
  const {
    projects,
    currentProject,
    activeTool,
    sidebarCollapsed,
    settings,
    setCurrentProject,
    setActiveTool,
    setSidebarCollapsed,
    updateSettings,
    canUndo,
    canRedo,
    undo,
    redo
  } = useAppStore();

  const [creatingProject, setCreatingProject] = useState(false);

  // Ferramentas disponíveis
  const tools = [
    {
      id: 'image',
      label: 'Gerador de Imagens',
      icon: Image,
      description: 'Crie imagens com IA'
    },
    {
      id: 'text',
      label: 'Gerador de Textos',
      icon: FileText,
      description: 'Gere textos e conteúdo'
    },
    {
      id: 'audio',
      label: 'Gerador de Áudio',
      icon: Mic,
      description: 'Síntese de voz e áudio'
    },
    {
      id: 'chat',
      label: 'Assistente IA',
      icon: MessageSquare,
      description: 'Converse com a IA'
    }
  ];

  // Criar novo projeto
  const createNewProject = async (type: 'image' | 'text' | 'audio' | 'mixed') => {
    setCreatingProject(true);
    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `Novo Projeto ${type === 'image' ? 'de Imagem' : type === 'text' ? 'de Texto' : type === 'audio' ? 'de Áudio' : 'Misto'}`,
          type,
          description: `Projeto criado em ${new Date().toLocaleString('pt-BR')}`
        })
      });
      
      if (response.ok) {
        const newProject = await response.json();
        setCurrentProject(newProject);
        setActiveTool(type);
      }
    } catch (error) {
      console.error('Erro ao criar projeto:', error);
    } finally {
      setCreatingProject(false);
    }
  };

  // Alternar tema
  const toggleTheme = () => {
    const themes: ('light' | 'dark' | 'auto')[] = ['light', 'dark', 'auto'];
    const currentIndex = themes.indexOf(settings.theme);
    const nextTheme = themes[(currentIndex + 1) % themes.length];
    updateSettings({ theme: nextTheme });
  };

  const getThemeIcon = () => {
    switch (settings.theme) {
      case 'dark': return Moon;
      case 'light': return Sun;
      default: return Monitor;
    }
  };

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden">
        <Sidebar variant="inset" collapsible="icon">
          <SidebarHeader className="border-b">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-600 to-blue-600">
                  <span className="text-sm font-bold text-white">KI</span>
                </div>
                <span className="font-semibold">King IA</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="h-8 w-8"
              >
                {React.createElement(getThemeIcon(), { className: 'h-4 w-4' })}
              </Button>
            </div>
          </SidebarHeader>

          <SidebarContent className="flex flex-col">
            <div className="p-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button className="w-full justify-start" disabled={creatingProject}>
                    <Plus className="mr-2 h-4 w-4" />
                    Novo Projeto
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => createNewProject('image')}>
                    <Image className="mr-2 h-4 w-4" />
                    Projeto de Imagem
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => createNewProject('text')}>
                    <FileText className="mr-2 h-4 w-4" />
                    Projeto de Texto
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => createNewProject('audio')}>
                    <Mic className="mr-2 h-4 w-4" />
                    Projeto de Áudio
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => createNewProject('mixed')}>
                    <Folder className="mr-2 h-4 w-4" />
                    Projeto Misto
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <Separator />

            <div className="p-4">
              <h3 className="mb-2 text-sm font-medium text-muted-foreground">Ferramentas</h3>
              <SidebarMenu>
                {tools.map((tool) => {
                  const Icon = tool.icon;
                  return (
                    <SidebarMenuItem key={tool.id}>
                      <SidebarMenuButton
                        isActive={activeTool === tool.id}
                        onClick={() => setActiveTool(tool.id as any)}
                        tooltip={tool.description}
                      >
                        <Icon className="h-4 w-4" />
                        <span>{tool.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </div>

            <Separator />

            <div className="flex-1 p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Projetos</h3>
                <Badge variant="secondary" className="text-xs">
                  {projects.length}
                </Badge>
              </div>
              <ScrollArea className="h-64">
                <SidebarMenu>
                  {projects.map((project) => (
                    <SidebarMenuItem key={project.id}>
                      <SidebarMenuButton
                        isActive={currentProject?.id === project.id}
                        onClick={() => setCurrentProject(project)}
                      >
                        <Folder className="h-4 w-4" />
                        <div className="flex-1 min-w-0">
                          <div className="truncate text-sm">{project.name}</div>
                          <div className="text-xs text-muted-foreground truncate">
                            {project.type}
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <MoreHorizontal className="h-3 w-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem>
                              <Archive className="mr-2 h-3 w-3" />
                              Arquivar
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-3 w-3" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </ScrollArea>
            </div>
          </SidebarContent>

          <SidebarFooter className="border-t">
            <div className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={undo}
                  disabled={!canUndo()}
                  className="flex-1"
                >
                  <Undo className="h-3 w-3 mr-1" />
                  Desfazer
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={redo}
                  disabled={!canRedo()}
                  className="flex-1"
                >
                  <Redo className="h-3 w-3 mr-1" />
                  Refazer
                </Button>
              </div>
              <Button variant="outline" size="sm" className="w-full">
                <Save className="h-3 w-3 mr-1" />
                Salvar Tudo
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex-1">
          <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            
            <div className="flex items-center flex-1 justify-between">
              <div>
                <h1 className="text-lg font-semibold">
                  {currentProject ? currentProject.name : 'Bem-vindo ao King IA'}
                </h1>
                {currentProject && (
                  <p className="text-sm text-muted-foreground">
                    {currentProject.description}
                  </p>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <History className="h-4 w-4 mr-2" />
                  Histórico
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  Configurações
                </Button>
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-hidden">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
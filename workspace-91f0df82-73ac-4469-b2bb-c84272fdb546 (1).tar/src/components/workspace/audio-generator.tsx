'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { ProgressIndicator, useProgress } from '@/components/ui/progress-indicator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Mic,
  Wand2,
  Download,
  RefreshCw,
  Settings,
  Sparkles,
  Play,
  Pause,
  Volume2,
  Voice
} from 'lucide-react';

export function AudioGeneratorWorkspace() {
  const [text, setText] = useState('');
  const [voice, setVoice] = useState('pt-BR-Female1');
  const [speed, setSpeed] = useState([1.0]);
  const [pitch, setPitch] = useState([1.0]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);
  
  const {
    progress,
    status,
    currentStep,
    currentStepNumber,
    totalSteps,
    error,
    startProgress,
    updateProgress,
    completeProgress,
    errorProgress,
    resetProgress
  } = useProgress(15); // 15 segundos estimado

  const voiceOptions = [
    { id: 'pt-BR-Female1', name: 'Voz Feminina 1', language: 'Português (BR)' },
    { id: 'pt-BR-Male1', name: 'Voz Masculina 1', language: 'Português (BR)' },
    { id: 'en-US-Female1', name: 'Female Voice 1', language: 'English (US)' },
    { id: 'en-US-Male1', name: 'Male Voice 1', language: 'English (US)' }
  ];

  const generateAudio = async () => {
    if (!text.trim()) return;
    
    setIsGenerating(true);
    resetProgress();
    
    const steps = [
      'Analisando texto...',
      'Selecionando voz...',
      'Processando áudio...',
      'Otimizando qualidade...',
      'Finalizando...'
    ];
    
    startProgress(steps);
    
    try {
      // Simular progresso detalhado
      updateProgress(15, steps[0], 1);
      await new Promise(resolve => setTimeout(resolve, 400));
      
      updateProgress(30, steps[1], 2);
      await new Promise(resolve => setTimeout(resolve, 600));
      
      updateProgress(50, steps[2], 3);
      
      const response = await fetch('/api/generate/audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice,
          speed: speed[0],
          pitch: pitch[0]
        })
      });

      updateProgress(80, steps[3], 4);
      
      if (response.ok) {
        const result = await response.json();
        
        updateProgress(95, steps[4], 5);
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setGeneratedAudio(result.audioUrl);
        updateProgress(100, steps[4], 5);
        completeProgress();
        
        setTimeout(() => {
          resetProgress();
          setIsGenerating(false);
        }, 2000);
      } else {
        throw new Error('Erro na resposta do servidor');
      }
    } catch (error) {
      console.error('Erro ao gerar áudio:', error);
      errorProgress(error instanceof Error ? error.message : 'Erro desconhecido');
      setIsGenerating(false);
    }
  };

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
    // Implementar reprodução de áudio aqui
  };

  return (
    <div className="flex h-full">
      {/* Painel de Controle */}
      <div className="w-80 border-r bg-muted/10">
        <ScrollArea className="h-full p-4">
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wand2 className="h-5 w-5" />
                  Geração de Áudio
                </CardTitle>
                <CardDescription>
                  Converta texto em fala com IA
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="text">Texto para Converter</Label>
                  <Textarea
                    id="text"
                    placeholder="Digite o texto que você deseja converter em áudio..."
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="min-h-[120px] mt-1"
                  />
                </div>

                <div>
                  <Label>Voz</Label>
                  <Select value={voice} onValueChange={setVoice}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {voiceOptions.map((v) => (
                        <SelectItem key={v.id} value={v.id}>
                          <div>
                            <div className="font-medium">{v.name}</div>
                            <div className="text-xs text-muted-foreground">{v.language}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Velocidade: {speed[0].toFixed(1)}x</Label>
                  <Slider
                    value={speed}
                    onValueChange={setSpeed}
                    max={2.0}
                    min={0.5}
                    step={0.1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Tom: {pitch[0].toFixed(1)}</Label>
                  <Slider
                    value={pitch}
                    onValueChange={setPitch}
                    max={2.0}
                    min={0.5}
                    step={0.1}
                    className="mt-2"
                  />
                </div>

                <Button 
                  onClick={generateAudio} 
                  disabled={isGenerating || !text.trim()}
                  className="w-full"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Gerar Áudio
                    </>
                  )}
                </Button>

                {status !== 'idle' && (
                  <ProgressIndicator
                    progress={progress}
                    status={status}
                    estimatedTime={15}
                    currentStep={currentStep}
                    totalSteps={totalSteps}
                    currentStepNumber={currentStepNumber}
                    error={error}
                  />
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" className="h-auto p-3 flex flex-col gap-1">
                    <Voice className="h-4 w-4" />
                    <span className="text-xs">Gravar</span>
                  </Button>
                  <Button variant="outline" size="sm" className="h-auto p-3 flex flex-col gap-1">
                    <Volume2 className="h-4 w-4" />
                    <span className="text-xs">Testar</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </div>

      {/* Área de Resultados */}
      <div className="flex-1">
        <Tabs defaultValue="player" className="h-full flex flex-col">
          <div className="border-b px-4 py-2">
            <TabsList>
              <TabsTrigger value="player">Player</TabsTrigger>
              <TabsTrigger value="library">Biblioteca</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="player" className="flex-1 p-4">
            <div className="h-full flex items-center justify-center">
              {isGenerating || status === 'processing' ? (
                <div className="text-center space-y-4">
                  <div className="relative">
                    <div className="w-32 h-32 border-4 border-muted rounded-full animate-pulse" />
                    <Mic className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-8 w-8 animate-pulse text-primary" />
                  </div>
                  <div>
                    <p className="text-lg font-medium">
                      {status === 'processing' ? `${currentStep} (${Math.round(progress)}%)` : 'Iniciando...'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {status === 'processing' ? `Passo ${currentStepNumber} de ${totalSteps}` : 'Isso pode levar alguns segundos'}
                    </p>
                  </div>
                </div>
              ) : generatedAudio ? (
                <div className="max-w-2xl mx-auto space-y-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-medium">Áudio Gerado</h3>
                          <p className="text-sm text-muted-foreground">
                            {text.substring(0, 100)}{text.length > 100 ? '...' : ''}
                          </p>
                        </div>
                        <Badge variant="secondary">{voice}</Badge>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <Button
                          size="lg"
                          onClick={togglePlayback}
                          className="rounded-full w-16 h-16"
                        >
                          {isPlaying ? (
                            <Pause className="h-6 w-6" />
                          ) : (
                            <Play className="h-6 w-6" />
                          )}
                        </Button>
                        
                        <div className="flex-1">
                          <div className="h-2 bg-muted rounded-full">
                            <div className="h-2 bg-primary rounded-full w-1/3"></div>
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground mt-1">
                            <span>0:00</span>
                            <span>0:00</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 pt-4">
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Baixar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="h-4 w-4 mr-2" />
                          Configurações
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <Mic className="h-16 w-16 text-muted-foreground mx-auto" />
                  <div>
                    <p className="text-lg font-medium">Nenhum áudio gerado ainda</p>
                    <p className="text-sm text-muted-foreground">
                      Digite o texto que você deseja converter em áudio e clique em "Gerar Áudio"
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="library" className="flex-1 p-4">
            <ScrollArea className="h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Biblioteca de Áudios</CardTitle>
                    <CardDescription>
                      Seus áudios gerados anteriormente
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">Nenhum áudio salvo ainda.</p>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="history" className="flex-1 p-4">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Histórico de Gerações</CardTitle>
                  <CardDescription>
                    Suas gerações de áudio anteriores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Nenhuma geração anterior encontrada.</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
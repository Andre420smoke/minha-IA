'use client';

import React from 'react';
import { useAppStore } from '@/lib/stores/app-store';
import { ImageGeneratorWorkspace } from './image-generator';
import { TextGeneratorWorkspace } from './text-generator';
import { AudioGeneratorWorkspace } from './audio-generator';
import { ChatWorkspace } from './chat-workspace';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Image,
  FileText,
  Mic,
  MessageSquare,
  Plus,
  Sparkles,
  Zap,
  Palette
} from 'lucide-react';

export function WorkspaceArea() {
  const { activeTool, currentProject, setActiveTool } = useAppStore();

  // Se não há projeto ativo, mostrar tela de boas-vindas
  if (!currentProject) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-600 to-blue-600">
                <Sparkles className="h-10 w-10 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-4">Bem-vindo ao King IA</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Sua plataforma completa de criação com inteligência artificial
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTool('image')}>
              <CardHeader className="text-center">
                <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100 dark:bg-purple-900">
                  <Image className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle className="text-lg">Gerador de Imagens</CardTitle>
                <CardDescription>
                  Crie imagens impressionantes com IA
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Começar
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTool('text')}>
              <CardHeader className="text-center">
                <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900">
                  <FileText className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle className="text-lg">Gerador de Textos</CardTitle>
                <CardDescription>
                  Escreva conteúdo com assistência de IA
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Começar
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTool('audio')}>
              <CardHeader className="text-center">
                <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-green-100 dark:bg-green-900">
                  <Mic className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle className="text-lg">Gerador de Áudio</CardTitle>
                <CardDescription>
                  Síntese de voz e criação de áudio
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Começar
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTool('chat')}>
              <CardHeader className="text-center">
                <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100 dark:bg-orange-900">
                  <MessageSquare className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
                <CardTitle className="text-lg">Assistente IA</CardTitle>
                <CardDescription>
                  Converse com nossa inteligência artificial
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Começar
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              <Plus className="mr-2 h-5 w-5" />
              Criar Novo Projeto
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Renderizar a área de trabalho baseada na ferramenta ativa
  switch (activeTool) {
    case 'image':
      return <ImageGeneratorWorkspace />;
    case 'text':
      return <TextGeneratorWorkspace />;
    case 'audio':
      return <AudioGeneratorWorkspace />;
    case 'chat':
      return <ChatWorkspace />;
    default:
      return (
        <div className="h-full flex items-center justify-center">
          <div className="text-center">
            <Zap className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Selecione uma ferramenta</h2>
            <p className="text-muted-foreground">Escolha uma das ferramentas disponíveis para começar</p>
          </div>
        </div>
      );
  }
}
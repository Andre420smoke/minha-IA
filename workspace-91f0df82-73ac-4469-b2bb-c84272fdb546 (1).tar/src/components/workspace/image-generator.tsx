'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { ProgressIndicator, useProgress } from '@/components/ui/progress-indicator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Image as ImageIcon,
  Wand2,
  Download,
  RefreshCw,
  Settings,
  Sparkles,
  Palette,
  Camera,
  Brush
} from 'lucide-react';

export function ImageGeneratorWorkspace() {
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [model, setModel] = useState('dall-e-3');
  const [size, setSize] = useState([1024]);
  const [quality, setQuality] = useState([80]);
  const [steps, setSteps] = useState([20]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  
  const {
    progress,
    status,
    currentStep,
    currentStepNumber,
    totalSteps,
    error,
    startProgress,
    updateProgress,
    completeProgress,
    errorProgress,
    resetProgress
  } = useProgress(30); // 30 segundos estimado

  const imageModels = [
    { id: 'dall-e-3', name: 'DALL-E 3', provider: 'OpenAI' },
    { id: 'stable-diffusion-xl', name: 'Stable Diffusion XL', provider: 'Stability AI' },
    { id: 'midjourney-v6', name: 'Midjourney v6', provider: 'Midjourney' },
    { id: 'firefly', name: 'Adobe Firefly', provider: 'Adobe' }
  ];

  const stylePresets = [
    { id: 'photorealistic', name: 'Fotográfico', icon: Camera },
    { id: 'artistic', name: 'Artístico', icon: Palette },
    { id: 'cartoon', name: 'Cartoon', icon: Brush },
    { id: 'minimalist', name: 'Minimalista', icon: Sparkles }
  ];

  const generateImage = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    resetProgress();
    
    const steps = [
      'Validando parâmetros...',
      'Conectando à IA...',
      'Enviando requisição...',
      'Processando imagem...',
      'Otimizando qualidade...',
      'Finalizando...'
    ];
    
    startProgress(steps);
    
    try {
      // Simular progresso detalhado
      updateProgress(10, steps[0], 1);
      await new Promise(resolve => setTimeout(resolve, 500));
      
      updateProgress(25, steps[1], 2);
      await new Promise(resolve => setTimeout(resolve, 800));
      
      updateProgress(40, steps[2], 3);
      
      const response = await fetch('/api/generate/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          negativePrompt,
          model,
          size: size[0],
          quality: quality[0],
          steps: steps[0]
        })
      });

      updateProgress(70, steps[3], 4);
      
      if (response.ok) {
        const result = await response.json();
        
        updateProgress(90, steps[4], 5);
        await new Promise(resolve => setTimeout(resolve, 500));
        
        setGeneratedImages(prev => [...prev, result.imageUrl]);
        updateProgress(100, steps[5], 6);
        completeProgress();
        
        setTimeout(() => {
          resetProgress();
          setIsGenerating(false);
        }, 2000);
      } else {
        throw new Error('Erro na resposta do servidor');
      }
    } catch (error) {
      console.error('Erro ao gerar imagem:', error);
      errorProgress(error instanceof Error ? error.message : 'Erro desconhecido');
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex h-full">
      {/* Painel de Controle */}
      <div className="w-80 border-r bg-muted/10">
        <ScrollArea className="h-full p-4">
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wand2 className="h-5 w-5" />
                  Geração de Imagem
                </CardTitle>
                <CardDescription>
                  Descreva a imagem que você deseja criar
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="prompt">Prompt Principal</Label>
                  <Textarea
                    id="prompt"
                    placeholder="Ex: Um gato astronauta flutuando no espaço..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[100px] mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="negative">Prompt Negativo</Label>
                  <Textarea
                    id="negative"
                    placeholder="O que não deve aparecer na imagem..."
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    className="min-h-[60px] mt-1"
                  />
                </div>

                <div>
                  <Label>Modelo de IA</Label>
                  <Select value={model} onValueChange={setModel}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {imageModels.map((m) => (
                        <SelectItem key={m.id} value={m.id}>
                          <div>
                            <div className="font-medium">{m.name}</div>
                            <div className="text-xs text-muted-foreground">{m.provider}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Tamanho: {size[0]}x{size[0]}</Label>
                  <Slider
                    value={size}
                    onValueChange={setSize}
                    max={2048}
                    min={256}
                    step={256}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Qualidade: {quality[0]}%</Label>
                  <Slider
                    value={quality}
                    onValueChange={setQuality}
                    max={100}
                    min={10}
                    step={10}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Passos: {steps[0]}</Label>
                  <Slider
                    value={steps}
                    onValueChange={setSteps}
                    max={50}
                    min={10}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <Button 
                  onClick={generateImage} 
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Gerar Imagem
                    </>
                  )}
                </Button>

                {status !== 'idle' && (
                  <ProgressIndicator
                    progress={progress}
                    status={status}
                    estimatedTime={30}
                    currentStep={currentStep}
                    totalSteps={totalSteps}
                    currentStepNumber={currentStepNumber}
                    error={error}
                  />
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Estilos Rápidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {stylePresets.map((preset) => {
                    const Icon = preset.icon;
                    return (
                      <Button
                        key={preset.id}
                        variant="outline"
                        size="sm"
                        className="h-auto p-3 flex flex-col gap-1"
                      >
                        <Icon className="h-4 w-4" />
                        <span className="text-xs">{preset.name}</span>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </div>

      {/* Área de Resultados */}
      <div className="flex-1">
        <Tabs defaultValue="current" className="h-full flex flex-col">
          <div className="border-b px-4 py-2">
            <TabsList>
              <TabsTrigger value="current">Geração Atual</TabsTrigger>
              <TabsTrigger value="gallery">Galeria</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="current" className="flex-1 p-4">
            <div className="h-full flex items-center justify-center">
              {isGenerating || status === 'processing' ? (
                <div className="text-center space-y-4">
                  <div className="relative">
                    <div className="w-32 h-32 border-4 border-muted rounded-lg animate-pulse" />
                    <RefreshCw className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-8 w-8 animate-spin text-primary" />
                  </div>
                  <div>
                    <p className="text-lg font-medium">
                      {status === 'processing' ? `${currentStep} (${Math.round(progress)}%)` : 'Iniciando...'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {status === 'processing' ? `Passo ${currentStepNumber} de ${totalSteps}` : 'Isso pode levar alguns segundos'}
                    </p>
                  </div>
                </div>
              ) : generatedImages.length > 0 ? (
                <div className="max-w-4xl mx-auto space-y-4">
                  <div className="relative group">
                    <img 
                      src={generatedImages[generatedImages.length - 1]} 
                      alt="Generated"
                      className="w-full rounded-lg shadow-lg"
                    />
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="flex gap-2">
                        <Button size="sm" variant="secondary">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="secondary">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">Prompt:</p>
                      <p className="text-sm text-muted-foreground">{prompt}</p>
                    </div>
                    <Badge variant="secondary">{model}</Badge>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto" />
                  <div>
                    <p className="text-lg font-medium">Nenhuma imagem gerada ainda</p>
                    <p className="text-sm text-muted-foreground">
                      Descreva a imagem que você deseja criar e clique em "Gerar Imagem"
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="gallery" className="flex-1 p-4">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {generatedImages.map((image, index) => (
                  <div key={index} className="relative group">
                    <img 
                      src={image} 
                      alt={`Generated ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg shadow-md"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                      <div className="flex gap-2">
                        <Button size="sm" variant="secondary">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="secondary">
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="history" className="flex-1 p-4">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Histórico de Gerações</CardTitle>
                  <CardDescription>
                    Suas gerações de imagens anteriores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Nenhuma geração anterior encontrada.</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
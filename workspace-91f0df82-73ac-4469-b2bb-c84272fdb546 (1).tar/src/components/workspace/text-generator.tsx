'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { ProgressIndicator, useProgress } from '@/components/ui/progress-indicator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  FileText,
  Wand2,
  Download,
  RefreshCw,
  Settings,
  Sparkles,
  Copy,
  Save,
  MessageSquare,
  PenTool,
  BookOpen,
  Code
} from 'lucide-react';

export function TextGeneratorWorkspace() {
  const [prompt, setPrompt] = useState('');
  const [context, setContext] = useState('');
  const [model, setModel] = useState('gpt-4');
  const [tone, setTone] = useState('professional');
  const [length, setLength] = useState([500]);
  const [temperature, setTemperature] = useState([0.7]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedText, setGeneratedText] = useState('');
  
  const {
    progress,
    status,
    currentStep,
    currentStepNumber,
    totalSteps,
    error,
    startProgress,
    updateProgress,
    completeProgress,
    errorProgress,
    resetProgress
  } = useProgress(20); // 20 segundos estimado

  const textModels = [
    { id: 'gpt-4', name: 'GPT-4', provider: 'OpenAI', maxTokens: 8192 },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', provider: 'OpenAI', maxTokens: 4096 },
    { id: 'claude-3', name: 'Claude 3', provider: 'Anthropic', maxTokens: 100000 },
    { id: 'gemini-pro', name: 'Gemini Pro', provider: 'Google', maxTokens: 32768 }
  ];

  const textTypes = [
    { id: 'blog', name: 'Post de Blog', icon: BookOpen },
    { id: 'email', name: 'E-mail', icon: MessageSquare },
    { id: 'creative', name: 'Texto Criativo', icon: PenTool },
    { id: 'code', name: 'Código', icon: Code }
  ];

  const toneOptions = [
    { id: 'professional', name: 'Profissional' },
    { id: 'casual', name: 'Informal' },
    { id: 'friendly', name: 'Amigável' },
    { id: 'academic', name: 'Acadêmico' },
    { id: 'creative', name: 'Criativo' },
    { id: 'technical', name: 'Técnico' }
  ];

  const generateText = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    resetProgress();
    
    const steps = [
      'Analisando prompt...',
      'Preparando contexto...',
      'Conectando à IA...',
      'Gerando texto...',
      'Refinando conteúdo...',
      'Finalizando...'
    ];
    
    startProgress(steps);
    
    try {
      // Simular progresso detalhado
      updateProgress(10, steps[0], 1);
      await new Promise(resolve => setTimeout(resolve, 300));
      
      updateProgress(20, steps[1], 2);
      await new Promise(resolve => setTimeout(resolve, 500));
      
      updateProgress(30, steps[2], 3);
      
      const response = await fetch('/api/generate/text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          context,
          model,
          tone,
          maxLength: length[0],
          temperature: temperature[0]
        })
      });

      updateProgress(70, steps[3], 4);
      
      if (response.ok) {
        const result = await response.json();
        
        updateProgress(90, steps[4], 5);
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setGeneratedText(result.text);
        updateProgress(100, steps[5], 6);
        completeProgress();
        
        setTimeout(() => {
          resetProgress();
          setIsGenerating(false);
        }, 2000);
      } else {
        throw new Error('Erro na resposta do servidor');
      }
    } catch (error) {
      console.error('Erro ao gerar texto:', error);
      errorProgress(error instanceof Error ? error.message : 'Erro desconhecido');
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedText);
  };

  const downloadText = () => {
    const blob = new Blob([generatedText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'generated-text.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-full">
      {/* Painel de Controle */}
      <div className="w-80 border-r bg-muted/10">
        <ScrollArea className="h-full p-4">
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wand2 className="h-5 w-5" />
                  Geração de Texto
                </CardTitle>
                <CardDescription>
                  Descreva o texto que você deseja criar
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="prompt">Prompt Principal</Label>
                  <Textarea
                    id="prompt"
                    placeholder="Ex: Escreva um artigo sobre os benefícios da inteligência artificial..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[100px] mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="context">Contexto Adicional</Label>
                  <Textarea
                    id="context"
                    placeholder="Informações adicionais para personalizar o texto..."
                    value={context}
                    onChange={(e) => setContext(e.target.value)}
                    className="min-h-[80px] mt-1"
                  />
                </div>

                <div>
                  <Label>Modelo de IA</Label>
                  <Select value={model} onValueChange={setModel}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {textModels.map((m) => (
                        <SelectItem key={m.id} value={m.id}>
                          <div>
                            <div className="font-medium">{m.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {m.provider} • {m.maxTokens.toLocaleString()} tokens
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Tom do Texto</Label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {toneOptions.map((option) => (
                        <SelectItem key={option.id} value={option.id}>
                          {option.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Comprimento: {length[0]} palavras</Label>
                  <Slider
                    value={length}
                    onValueChange={setLength}
                    max={2000}
                    min={50}
                    step={50}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Criatividade: {temperature[0]}</Label>
                  <Slider
                    value={temperature}
                    onValueChange={setTemperature}
                    max={2}
                    min={0}
                    step={0.1}
                    className="mt-2"
                  />
                </div>

                <Button 
                  onClick={generateText} 
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Gerar Texto
                    </>
                  )}
                </Button>

                {status !== 'idle' && (
                  <ProgressIndicator
                    progress={progress}
                    status={status}
                    estimatedTime={20}
                    currentStep={currentStep}
                    totalSteps={totalSteps}
                    currentStepNumber={currentStepNumber}
                    error={error}
                  />
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Tipos de Texto</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {textTypes.map((type) => {
                    const Icon = type.icon;
                    return (
                      <Button
                        key={type.id}
                        variant="outline"
                        size="sm"
                        className="h-auto p-3 flex flex-col gap-1"
                      >
                        <Icon className="h-4 w-4" />
                        <span className="text-xs">{type.name}</span>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </div>

      {/* Área de Resultados */}
      <div className="flex-1">
        <Tabs defaultValue="editor" className="h-full flex flex-col">
          <div className="border-b px-4 py-2">
            <TabsList>
              <TabsTrigger value="editor">Editor</TabsTrigger>
              <TabsTrigger value="preview">Visualização</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="editor" className="flex-1 p-4">
            <div className="h-full flex flex-col">
              {isGenerating || status === 'processing' ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="relative">
                      <FileText className="h-16 w-16 text-muted-foreground mx-auto" />
                      <RefreshCw className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-8 w-8 animate-spin text-primary" />
                    </div>
                    <div>
                      <p className="text-lg font-medium">
                        {status === 'processing' ? `${currentStep} (${Math.round(progress)}%)` : 'Iniciando...'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {status === 'processing' ? `Passo ${currentStepNumber} de ${totalSteps}` : 'Isso pode levar alguns segundos'}
                      </p>
                    </div>
                  </div>
                </div>
              ) : generatedText ? (
                <div className="flex-1 flex flex-col">
                  <div className="mb-4 flex justify-between items-center">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={copyToClipboard}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copiar
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadText}>
                        <Download className="h-4 w-4 mr-2" />
                        Baixar
                      </Button>
                      <Button size="sm" variant="outline">
                        <Save className="h-4 w-4 mr-2" />
                        Salvar
                      </Button>
                    </div>
                    <Badge variant="secondary">{model}</Badge>
                  </div>
                  <Textarea
                    value={generatedText}
                    onChange={(e) => setGeneratedText(e.target.value)}
                    className="flex-1 min-h-[400px] font-mono text-sm"
                    placeholder="Seu texto gerado aparecerá aqui..."
                  />
                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <FileText className="h-16 w-16 text-muted-foreground mx-auto" />
                    <div>
                      <p className="text-lg font-medium">Nenhum texto gerado ainda</p>
                      <p className="text-sm text-muted-foreground">
                        Descreva o texto que você deseja criar e clique em "Gerar Texto"
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="preview" className="flex-1 p-4">
            <ScrollArea className="h-full">
              <div className="max-w-4xl mx-auto">
                {generatedText ? (
                  <div className="prose prose-gray max-w-none">
                    <h1>Pré-visualização do Texto</h1>
                    <div className="whitespace-pre-wrap">{generatedText}</div>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground">
                    <p> gere um texto para visualizá-lo aqui.</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="history" className="flex-1 p-4">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Histórico de Gerações</CardTitle>
                  <CardDescription>
                    Suas gerações de texto anteriores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Nenhuma geração anterior encontrada.</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
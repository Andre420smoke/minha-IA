'use client';

import React, { useState, useEffect } from 'react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Clock, 
  Zap, 
  CheckCircle, 
  AlertCircle, 
  Loader2 
} from 'lucide-react';

interface ProgressIndicatorProps {
  progress: number;
  status: 'idle' | 'processing' | 'completed' | 'error';
  estimatedTime?: number; // em segundos
  currentStep?: string;
  totalSteps?: number;
  currentStepNumber?: number;
  error?: string;
}

export function ProgressIndicator({
  progress,
  status,
  estimatedTime,
  currentStep,
  totalSteps,
  currentStepNumber,
  error
}: ProgressIndicatorProps) {
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(estimatedTime || 0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (status === 'processing') {
      interval = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
        
        if (estimatedTime && progress > 0) {
          const totalTime = estimatedTime;
          const elapsed = (progress / 100) * totalTime;
          const remaining = Math.max(0, totalTime - elapsed);
          setTimeRemaining(remaining);
        }
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [status, progress, estimatedTime]);

  const formatTime = (seconds: number) => {
    if (seconds < 60) {
      return `${Math.round(seconds)}s`;
    } else if (seconds < 3600) {
      const mins = Math.floor(seconds / 60);
      const secs = Math.round(seconds % 60);
      return `${mins}m ${secs}s`;
    } else {
      const hours = Math.floor(seconds / 3600);
      const mins = Math.floor((seconds % 3600) / 60);
      return `${hours}h ${mins}m`;
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'processing':
        return <Loader2 className="h-4 w-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Zap className="h-4 w-4" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'processing':
        return 'bg-blue-500';
      case 'completed':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'processing':
        return 'Processando...';
      case 'completed':
        return 'Concluído!';
      case 'error':
        return 'Erro';
      default:
        return 'Aguardando...';
    }
  };

  if (status === 'idle') {
    return null;
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4 space-y-3">
        {/* Cabeçalho do Progresso */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <span className="font-medium text-sm">{getStatusText()}</span>
            <Badge variant="secondary" className="text-xs">
              {Math.round(progress)}%
            </Badge>
          </div>
          
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            {status === 'processing' && timeRemaining > 0 && (
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{formatTime(timeRemaining)}</span>
              </div>
            )}
            {timeElapsed > 0 && (
              <div className="flex items-center gap-1">
                <span>Tempo: {formatTime(timeElapsed)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Barra de Progresso Principal */}
        <div className="space-y-2">
          <Progress 
            value={progress} 
            className="h-2"
            // @ts-ignore - Adicionando cor dinâmica
            style={{ 
              '--progress-background': getStatusColor()
            } as React.CSSProperties}
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0%</span>
            <span>{Math.round(progress)}%</span>
            <span>100%</span>
          </div>
        </div>

        {/* Passos Detalhados */}
        {currentStep && totalSteps && currentStepNumber && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Passo {currentStepNumber} de {totalSteps}</span>
              <span className="font-medium">{currentStep}</span>
            </div>
            <Progress 
              value={(currentStepNumber / totalSteps) * 100} 
              className="h-1"
            />
          </div>
        )}

        {/* Mensagem de Erro */}
        {error && status === 'error' && (
          <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-red-700 dark:text-red-300">
                <p className="font-medium">Ocorreu um erro</p>
                <p className="text-xs mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Indicadores Visuais */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${getStatusColor()}`}></div>
            <span className="text-xs text-muted-foreground">
              {status === 'processing' && 'Em andamento'}
              {status === 'completed' && 'Concluído com sucesso'}
              {status === 'error' && 'Falha na operação'}
            </span>
          </div>
          
          {progress === 100 && status === 'completed' && (
            <Badge variant="default" className="text-xs bg-green-500">
              <CheckCircle className="h-3 w-3 mr-1" />
              Sucesso
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Hook para gerenciar progresso de tarefas
export function useProgress(estimatedTime?: number) {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'processing' | 'completed' | 'error'>('idle');
  const [currentStep, setCurrentStep] = useState('');
  const [currentStepNumber, setCurrentStepNumber] = useState(0);
  const [totalSteps, setTotalSteps] = useState(0);
  const [error, setError] = useState('');

  const startProgress = (steps?: string[]) => {
    setProgress(0);
    setStatus('processing');
    setError('');
    if (steps) {
      setTotalSteps(steps.length);
      setCurrentStepNumber(1);
      setCurrentStep(steps[0] || '');
    }
  };

  const updateProgress = (newProgress: number, step?: string, stepNumber?: number) => {
    setProgress(newProgress);
    if (step) setCurrentStep(step);
    if (stepNumber) setCurrentStepNumber(stepNumber);
  };

  const completeProgress = () => {
    setProgress(100);
    setStatus('completed');
    setCurrentStep('Concluído');
  };

  const errorProgress = (errorMessage: string) => {
    setStatus('error');
    setError(errorMessage);
  };

  const resetProgress = () => {
    setProgress(0);
    setStatus('idle');
    setCurrentStep('');
    setCurrentStepNumber(0);
    setTotalSteps(0);
    setError('');
  };

  return {
    progress,
    status,
    currentStep,
    currentStepNumber,
    totalSteps,
    error,
    estimatedTime,
    startProgress,
    updateProgress,
    completeProgress,
    errorProgress,
    resetProgress
  };
}
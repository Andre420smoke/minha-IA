# 📦 Guia de Compilação e Distribuição - King IA

## 🚀 Build para Produção

### 1. Preparação do Ambiente

```bash
# Verificar versão do Node.js
node --version  # Deve ser 18+ 

# Limpar cache e dependências
rm -rf .next node_modules package-lock.json
npm install

# Verificar lint e tipos
npm run lint
npm run type-check  # se disponível
```

### 2. Build Otimizado

```bash
# Build de produção
npm run build

# Verificar build gerado
ls -la .next/
```

### 3. Teste de Produção Local

```bash
# Iniciar servidor de produção
npm run start

# Acessar em http://localhost:3000
```

## 🐳 Dockerização

### Dockerfile
```dockerfile
# Multi-stage build para otimização
FROM node:18-alpine AS base
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM base AS builder
COPY . .
RUN npm ci
RUN npm run build

FROM base AS runner
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./package.json

EXPOSE 3000
ENV PORT 3000
ENV NODE_ENV production

CMD ["npm", "start"]
```

### Build e Execução
```bash
# Construir imagem
docker build -t king-ia:latest .

# Executar container
docker run -p 3000:3000 --name king-ia-app king-ia:latest

# Executar em background
docker run -d -p 3000:3000 --name king-ia-app king-ia:latest
```

### Docker Compose
```yaml
version: '3.8'
services:
  king-ia:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=file:./prod.db
    volumes:
      - ./data:/app/data
    restart: unless-stopped
```

## 🌐 Implantação em Nuvem

### Vercel (Recomendado)
```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# Configurar variáveis de ambiente
vercel env add DATABASE_URL
vercel env add NEXTAUTH_SECRET
```

### Netlify
```bash
# Build estático (se aplicável)
npm run build:static

# Deploy com Netlify CLI
npm install -g netlify-cli
netlify deploy --prod --dir=.next
```

### AWS Amplify
```bash
# Amplify CLI
npm install -g @aws-amplify/cli
amplify init
amplify add hosting
amplify publish
```

### DigitalOcean App Platform
1. Conectar repositório Git
2. Configurar build command: `npm run build`
3. Configurar run command: `npm start`
4. Definir variáveis de ambiente

## 📱 Build para Desktop (Electron)

### Instalação de Dependências
```bash
npm install --save-dev electron electron-builder
npm install --save-dev @electron/rebuild concurrently wait-on
```

### Configuração do Electron
```javascript
// electron.js
const { app, BrowserWindow } = require('electron');
const path = require('path');
const isDev = process.env.NODE_ENV === 'development';

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    mainWindow.loadFile(path.join(__dirname, '../out/index.html'));
  }
}

app.whenReady().then(createWindow);
```

### Package.json para Desktop
```json
{
  "main": "public/electron.js",
  "homepage": "./",
  "scripts": {
    "electron": "electron .",
    "electron-dev": "concurrently \"npm run dev\" \"wait-on http://localhost:3000 && electron .\"",
    "electron-pack": "npm run build && electron-builder",
    "preelectron-pack": "npm run build"
  },
  "build": {
    "appId": "com.kingia.app",
    "productName": "King IA",
    "directories": {
      "output": "dist"
    },
    "files": [
      "build/**/*",
      "node_modules/**/*"
    ],
    "mac": {
      "category": "public.app-category.productivity"
    },
    "win": {
      "target": "nsis"
    },
    "linux": {
      "target": "AppImage"
    }
  }
}
```

### Build Desktop
```bash
# Desenvolvimento
npm run electron-dev

# Produção
npm run electron-pack
```

## 📊 Build para Mobile (React Native)

### Configuração Expo
```bash
# Instalar Expo CLI
npm install -g @expo/cli

# Iniciar projeto Expo
npx create-expo-app lasy-ia-mobile
```

### Adaptação para Mobile
```javascript
// App.js (Expo)
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './screens/HomeScreen';
import ImageGeneratorScreen from './screens/ImageGeneratorScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ImageGenerator" component={ImageGeneratorScreen} />
      </Stack.Navigator>
      <StatusBar style="auto" />
    </NavigationContainer>
  );
}
```

## 🔧 Otimizações de Build

### Análise de Bundle
```bash
# Analisar tamanho do bundle
npm install --save-dev @next/bundle-analyzer
npx @next/bundle-analyzer

# Webpack Bundle Analyzer
npm run build
npx webpack-bundle-analyzer .next/static/chunks/*.js
```

### Otimizações Avançadas
```javascript
// next.config.js
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
});

module.exports = withBundleAnalyzer({
  experimental: {
    optimizeCss: true,
    optimizePackageImports: ['lucide-react', '@radix-ui/react-icons']
  },
  images: {
    formats: ['image/webp', 'image/avif'],
    minimumCacheTTL: 60 * 60 * 24 * 30, // 30 days
  },
  compress: true,
  poweredByHeader: false,
  generateEtags: false,
});
```

## 🚀 CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run lint
      - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
          vercel-args: '--prod'
```

## 📈 Monitoramento e Analytics

### Configuração de Monitoramento
```javascript
// lib/monitoring.js
import { Analytics } from '@vercel/analytics/react';

export function reportWebVitals(metric) {
  // Enviar métricas para analytics
  if (window.gtag) {
    window.gtag('event', metric.name, {
      value: Math.round(metric.value),
      event_category: 'Web Vitals'
    });
  }
}
```

### Performance Monitoring
```bash
# Lighthouse CI
npm install -g @lhci/cli
lhci autorun
```

## 🔐 Segurança em Produção

### Headers de Segurança
```javascript
// next.config.js
const securityHeaders = [
  {
    key: 'X-DNS-Prefetch-Control',
    value: 'on'
  },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload'
  },
  {
    key: 'X-XSS-Protection',
    value: '1; mode=block'
  },
  {
    key: 'X-Frame-Options',
    value: 'DENY'
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  }
];

module.exports = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: securityHeaders,
      },
    ];
  },
};
```

## 📋 Checklist de Deploy

### Antes do Deploy
- [ ] Testes unitários passando
- [ ] Testes de integração passando
- [ ] Build sem erros
- [ ] Variáveis de ambiente configuradas
- [ ] Backup do banco de dados
- [ ] Análise de segurança
- [ ] Performance audit

### Pós-Deploy
- [ ] Verificar funcionamento
- [ ] Testar todas as funcionalidades
- [ ] Monitorar logs
- [ ] Verificar métricas
- [ ] Testar rollback se necessário

## 🆘 Troubleshooting

### Problemas Comuns

#### Build Falha
```bash
# Limpar completamente
rm -rf .next node_modules package-lock.json
npm install
npm run build
```

#### Problemas de Memória
```bash
# Aumentar limite Node
export NODE_OPTIONS="--max-old-space-size=4096"
npm run build
```

#### Problemas de CORS
```javascript
// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: '/api/(.*)',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET,OPTIONS,PATCH,DELETE,POST,PUT' },
        ],
      },
    ];
  },
};
```

---

Este guia cobre todos os aspectos da compilação e distribuição do LASY IA. Para dúvidas específicas, consulte a documentação oficial das tecnologias utilizadas.